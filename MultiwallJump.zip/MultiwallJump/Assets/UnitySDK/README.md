# Unity ML-Agents SDK

Contains the ML-Agents Unity Project, including 
both the core plugin (in `Scripts`), as well as a set 
of example environments (in `Examples`).